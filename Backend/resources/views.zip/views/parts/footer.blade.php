<script src="{{ url('adminpanel/js/jquery-1.11.1.min.js') }}"></script>
<script src="{{ url('adminpanel/js/jquery-migrate-1.2.1.min.js') }}"></script>
<script src="{{ url('adminpanel/js/jquery-ui-1.10.3.min.js') }}"></script>
<script src="{{ url('adminpanel/js/bootstrap.min.js') }}"></script>
<script src="{{ url('adminpanel/js/modernizr.min.js') }}"></script>
<script src="{{ url('adminpanel/js/jquery.sparkline.min.js') }}"></script>
<script src="{{ url('adminpanel/js/toggles.min.js') }}"></script>
<script src="{{ url('adminpanel/js/retina.min.js') }}"></script>
<script src="{{ url('adminpanel/js/jquery.cookies.js') }}"></script>

<script src="{{ url('adminpanel/js/morris.min.js') }}"></script>
<script src="{{ url('adminpanel/js/raphael-2.1.0.min.js') }}"></script>

<script src="{{ url('adminpanel/js/colorpicker.js') }}"></script>
<script src="{{ url('adminpanel/js/select2.min.js') }}"></script>

<script src="{{ url('adminpanel/js/custom.js') }}"></script>

